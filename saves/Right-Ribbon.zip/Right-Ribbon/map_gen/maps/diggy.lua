-- authors Linaori, valansch
require 'map_gen.maps.diggy.scenario'.register()
