return function(x, y)
    return not (x < -32 or y > 64 or y < -64)
end
